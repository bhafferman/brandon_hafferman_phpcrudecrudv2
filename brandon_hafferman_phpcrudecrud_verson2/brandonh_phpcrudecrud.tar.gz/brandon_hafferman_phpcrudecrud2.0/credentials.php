<?php
$servername = 'localhost';     //if apache on diff server from db or using Docker, set IP address
$dbname = 'employees';              //which db you're going to use
$username = 'brandon';
$password = 'Thething13!';
?>
