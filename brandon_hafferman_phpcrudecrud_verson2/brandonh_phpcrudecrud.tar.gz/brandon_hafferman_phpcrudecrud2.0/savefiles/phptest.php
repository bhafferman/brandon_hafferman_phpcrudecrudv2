<?php
phpinfo()
?>

